def printText():
    print("Hello, I am going as zip file to the lambda console")

printText()